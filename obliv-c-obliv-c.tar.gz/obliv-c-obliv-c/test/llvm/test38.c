#include <stdio.h>

static int x;

int main(int argc, char **argv)
{
  x = 2;
  printf("hello world %d\n", x);
  return 0;
}
