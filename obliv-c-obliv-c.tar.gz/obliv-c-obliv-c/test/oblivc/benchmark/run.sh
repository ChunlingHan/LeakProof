time $1 $2 $3 & (sleep 0.01;  $1 $2 $3)
#perf record $1 $2 $3 & (sleep 0.1;  $1 $2 $3)
