The command is:

// reach the file modprime
cd Desktop
cd obliv-c-obliv-c
cd test
cd oblivc
cd modprime


make

./a.out 1234 -- 24 &
./a.out 1234 localhost 56

Result:24

