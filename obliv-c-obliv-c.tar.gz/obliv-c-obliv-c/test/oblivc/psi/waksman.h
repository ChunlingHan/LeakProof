#pragma once
#include<stdbool.h>
#include<stddef.h>

size_t waksmanSwapCount(size_t n);
size_t waksmanNetwork(unsigned a[],unsigned b[],size_t n);
size_t waksmanSwitches(const unsigned arr[],unsigned n,bool output[]);
