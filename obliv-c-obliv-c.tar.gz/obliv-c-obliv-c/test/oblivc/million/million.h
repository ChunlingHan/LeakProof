typedef struct protocolIO
{ int cmp; // -1,0, or 1
  int mywealth;
} protocolIO;

void millionaire(void* args);
