int g1, g2, g3;

int test2(int a) {
  int b;
  g1 = g1 + 7;
  return b;
}

int test4() {
  int a,b;
  return test2(4);
}
  
int main() { return 0; }

