extern int printf (__const char *__restrict __format, ...)  ;

int main() {
  printf("Hello world\n");
  return 0;
}
