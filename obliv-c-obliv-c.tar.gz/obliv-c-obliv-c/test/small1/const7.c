/* There was a parsing error here */
static const int pi  =  3, s0  =  7;
