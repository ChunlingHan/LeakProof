// Demonstrate what happens when you call a function that is not
// defined.

int main() {
    int a = 3;
    gronkwaerawerawerwae(a);
    return 0;
}
