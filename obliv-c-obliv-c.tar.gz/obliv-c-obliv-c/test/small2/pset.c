

int main()
{
    int someVariable, restrict;

    return 0;
}
