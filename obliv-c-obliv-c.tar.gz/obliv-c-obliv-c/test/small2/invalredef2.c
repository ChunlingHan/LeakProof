
enum token {
  TERM = - 1
} ; /*onlytypedef*/


static int  parse(int *  ) ;

static int  parse(enum token *  tok )
{
  return 0;
}

int main () {
 return 0;
}
