
int main () {
  char c[8] = "an error!";
  return c[0] - 'a' + c[7] - 'r';
}
