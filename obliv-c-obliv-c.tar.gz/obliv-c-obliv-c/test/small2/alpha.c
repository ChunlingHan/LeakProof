
//KEEP baseline: success

const unsigned char G___152598331 = 0;
void f() {
  const unsigned char G___152598331 = 0;
}

//This suffix is so long that it will be alpha-renamed as G___1525983317___0
const unsigned char G___1525983317 = 0;
void f2() {
  const unsigned char G___1525983317 = 0;
}

const unsigned char G___1525983317999999999994352352523523993424999 = 0;
void f3() {
const unsigned char G__1525983317999999999994352352523523993424999 = 0;
}


const unsigned char G___999999999 = 0; //KEEP overflow:error = Encountered a variable name containing ___ and many digits
void f4() {
  const unsigned char G___152598331 = 0;
}

int main() {
  return 0;
}
