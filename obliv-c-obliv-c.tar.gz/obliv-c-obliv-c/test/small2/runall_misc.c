

int main (int argc, char **argv)
{
  return 0;
}
//Our parser was allowing trailing right braces
} //KEEP rbrace: error = syntax error

