#include <NTL/ZZ.h>
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <string>
#include <time.h>

using namespace std;
using namespace NTL;

ZZ N;
ZZ P;

int main()
{
	ZZ a,b,c,d,e,f;
	ZZ top,low;
	string filename,file_name;
	clock_t begin,end;
	ifstream infile;
	ofstream outfile;

	infile.open("public_key.txt");
	infile >> N;
	infile.close();
	
	cout << "Please input the file name you want to evaluate: ";
	cin >> filename;
	cout << "Please input the file name you want to store the evaluation result: ";
	cin >> file_name;
	infile.open(filename.c_str());
	outfile.open(file_name.c_str());


	begin=clock();
	while(infile >> a >> b >> c >> d >> e >>f)
	{

                a = (a*d+c*b)%N;
		b = (b*d)%N;
		top = (a*e)%N;
		low = (b*f)%N;
		
		outfile << top << endl << low << endl;	
	}
	end = clock();
	infile.close();
	outfile.close();
        cout << "The time is " << (double)(end-begin) / CLOCKS_PER_SEC << " s." << endl; 

	
	
}
