#include <NTL/ZZ.h>
#include <iostream>
#include <stdio.h>
#include <fstream>

using namespace std;
using namespace NTL;


ZZ P,Q,N;

int main()
{
	RandomPrime(P, 1024);
	RandomPrime(Q, 1024);
	N = P * Q;
	ofstream outfile;
	outfile.open("private_key.txt");
	outfile << P << endl;
	
	outfile.close();
	
	outfile.open("public_key.txt");
	outfile << N << endl;
	outfile.close();

	cout << "The Public key is N = " << N << endl;
	
	return 0;
}
