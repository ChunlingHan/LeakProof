#include <NTL/ZZ.h>
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <time.h>
#include <string>

using namespace std;
using namespace NTL;

ZZ N;
ZZ P;

int main()
{
	ZZ a,b,c,d,e,f,g,h,i,j,k,o;
	ZZ top,low;
	string filename,file_name;
        clock_t begin,end;
	
	ifstream infile;
	ofstream outfile;

	infile.open("public_key.txt");
	infile >> N;
	infile.close();
	
	cout << "Please input the file name you want to evaluate: ";
	cin >> filename;
	cout << "Please input the file name you want to store the evaluation result: ";
	cin >> file_name;
	infile.open(filename.c_str());
	outfile.open(file_name.c_str());


	begin=clock();
	while(infile >> a >> b >> c >> d >> e >> f >> g >> h >> i >> j >> k >> o)
	{
		a = (a*d+c*b)%N;
		b = (b*d)%N;
		
                a = (a*f+e*b)%N;
		b = (b*f)%N;

                a = (a*h+g*b)%N;
		b = (b*h)%N;
                
                a = (a*j+i*b)%N;
		b = (b*j)%N;
          
                a = (a*o+k*b)%N;
		b = (b*o)%N;

		outfile << a << endl << b << endl;	
	}
	end = clock();	
	infile.close();
	outfile.close();
	cout << "The time is " << (double)(end-begin) / CLOCKS_PER_SEC << " s." << endl; 
	
}
