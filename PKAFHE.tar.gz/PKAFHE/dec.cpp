#include <NTL/ZZ.h>
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <string>

using namespace std;
using namespace NTL;

ZZ N;
ZZ P;

int main()
{
	ZZ a,b;
	ZZ top,low;
	ZZ m;
	long s;
	string file_name;
	string filename;
	
	
	ifstream infile;
	ofstream outfile;

	infile.open("private_key.txt");
	infile >> P;
	infile.close();
	
	cout << "Please input the file name you want to decrypt: ";
	cin >> file_name;
	
	infile.open(file_name.c_str());
	outfile.open("decrypt.txt");

	cout << "Please input a file name to store the result of decryption: ";
	cin >> filename;
        cout << "Please input the accuracy of the demission: ";
	cin >> s;
	
	while(infile >> a >> b)
	{
		top = a % P;
		low = b % P;
		m = (top*s)/low;
		outfile << m << endl;	
	}
	
	infile.close();
	outfile.close();


	infile.open("decrypt.txt");
	outfile.open(filename.c_str());
	long re;
	double result;
	while(infile >> re)
	{
		result = (double)re/(double)s;
		outfile << result << endl;
		
	}
	
	infile.close();
	outfile.close();
	
}
