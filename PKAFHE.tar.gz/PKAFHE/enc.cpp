#include <NTL/ZZ.h>
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <string>
#include <time.h>
using namespace std;
using namespace NTL;

ZZ N;
ZZ P;

int main()
{
        clock_t begin,end;
	string filename,file_name;
	ifstream infile;
	ofstream outfile;
	infile.open("public_key.txt");
	infile >> N;
	infile.close();
	
	infile.open("private_key.txt");
	infile >> P;
	infile.close();

	
	double temp;
	ZZ d;
	ZZ deta;
	ZZ r;
	long m;
	ZZ s;
	ZZ a;
	ZZ b;
	
	cout << "Please input the name of your file you want to encrypt:";
	cin >> filename;
	cout << "Please input the dementional accuracy: ";
	cin >> m;
	
	cout << "Please input the file you store the ciphertext: ";
	cin >> file_name;
	cout << "The ciphertext are writen into file " << file_name.c_str() << "."<< endl;
	
	infile.open(filename.c_str());
	outfile.open(file_name.c_str());
        
        begin=clock();
	while(infile >> temp)
	{
		a = m;
		b = temp*m;
		d = GCD(a, b);
		
		b = b/d;
		a = a/d;
		deta = RandomBnd(100);
		while(deta==0)
		{
			deta = RandomBnd(100);
		}
		
		a = a*deta;
		b = b*deta;
		r = RandomBnd(100);	
		while(r==0);
		{
			r = RandomBnd(100);
		}
		a = PowerMod(a, r*(P-1)+1, N);
		b = PowerMod(b, r*(P-1)+1, N);
		outfile << b << endl << a << endl;
		
	}
	
        end = clock();	
	infile.close();
	outfile.close();

        cout << "The time is " << (double)(end-begin) / CLOCKS_PER_SEC << " s." << endl;     
	
}
